package solutions.workshop.june8.basic;

public class ConverterTest {

    public static void main(String[] args) {

    }
}
