package com.workshop.june8.bankingapi;

public class BankingApiTest {

}
