package com.workshop.june8.calculation;

public class CalculationTest {

    String now = "20200608";

}
