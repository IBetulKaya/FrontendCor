package com.workshop.june8.calculation.exception;

public class EndpointException extends Exception {

    public EndpointException(){
        super();
    }

    public EndpointException(String message){
        super( message);
    }

}
