package com.workshop.june8.basic;

public class Converter {

    public static double celciusToFahrenheit(double celcius){
        return  ((9*celcius)/5)+32;
    }

    public static double fahrenheitToCelcius(double fahrenheit){
        return  (fahrenheit-32)*5/9;
    }
}
