package com.workshop.june8.calculation.exception;

public class CalculationException extends Exception {

    public CalculationException(){
        super();
    }

    public CalculationException(String message){
        super( message);
    }

}

