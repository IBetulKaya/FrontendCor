<!--    CTRL + SHIFT + P to export to PDf-->

# JUnit 5 / Mockito

<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>

## For further reference, please consider the following sections:

* [https://www.baeldung.com/junit-before-beforeclass-beforeeach-beforeall](https://www.baeldung.com/junit-before-beforeclass-beforeeach-beforeall)
* [https://www.guru99.com/junit-assert.html](https://www.guru99.com/junit-assert.html)
* [https://www.baeldung.com/junit-5-test-order](https://www.baeldung.com/junit-5-test-order)

<br/><br/>

<div style="page-break-after: always;"></div>

## Preparing test data

Use annotated methods to set up test data

* Return type must be void.
* Method name is not important
* Method must be public

```java
// Is executed once before all tests
// For setting up test dependencies that open/use databases/network connections
// Must be public static

@BeforeAll
public static void setupAll() {

    // Prepare resources for test
    // I.e. run sql script to set up test data for whole all tests 

}
```

```java
// Execute before each test
// for resetting test cases/test data

@BeforeEach
public void setupEach() {

        // Prepare resources for test
        // I.e. run sql script to set up test data for this test 

}
```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Simple test

* Method must be public.
* Return type must be void.
* Method name is not important but must be meaningful
* Many methods (like assertEquals) need to be imported as static methods. 
* <ins>Note: We do not test private methods</ins>

```java
@Test
@Order(1)
public void testReservationListSize(){

    int count = reservationService.getReservationCount();
    assertEquals(1, count);

}
```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Assertions

### Evaluate test outcome with assertions


```java
int result = classToTest.sumOfItems( 3, 7, 4, 6);
assertEquals( 20, result);
```
```java
boolean result = classToTest.isNameInList("Aysegul", Arrays.asList("Jim","Halit","Muslum","Paula"));
assertFalse( result);
```
```java
Object result = classToTest.createReservation();
assertInstanceOf(Reservation.class, result);
```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Class responsibility

### We want to test the business rules that are implemented in the class. We mock the dependencies.

```java
private BankingService bankingService;

@Autowired
public InterestCalculator( BankingService bankingService){
this.bankingService = bankingService;
}

public double calculateInterest( double amount, int years, LocalDate date) throws CalculationException {

    double interestRate = 0;

    try {
        interestRate = bankingService.getInterestRate(date);
    } catch (EndpointException e) {
        throw new CalculationException("Calculation failed due to: " + e.getMessage());
    }

    return calculateInterest( amount, years, interestRate);
    
    private double calculateInterest( double amount, int years, double interestRate) throws CalculationException {
        .....
    }

}
```

## Mocking

![Alt text](./mocking.png)

## Mocking a class

```java
// First we create a list with test data
Reservation reservation1 = new Reservation(1, 100000001,
        LocalDateTime.now(),
        LocalDate.now().plusDays(1),
        LocalDate.now().plusDays(4),
        "50000324",
        "Mr. de Witt");

Reservation reservation2 = new Reservation(2, 100000002,
        LocalDateTime.now(),
        LocalDate.now().plusDays(1),
        LocalDate.now().plusDays(4),
        "50000325",
        "Mrs. de Witt");

List<Reservation> reservations = Arrays.asList( reservation1, reservation2);

// Then we create a mock object of an interface
reservationRepository = mock(ReservationRepository.class);

// We instruct the mock to return the list whenever method getReservations is called
when( reservationRepository.getReservations()).thenReturn( reservations);

```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Mocking an interface

```java
@Service
public interface BankingApi {

    Account login(String pincode) throws BankingApiException;
    boolean transfer(double amount, String accountNrFrom,String accountNrTo) throws BankingApiException;
    double getBalance(String accountNr) throws BankingApiException;
    boolean applyForLone(Account account) throws BankingApiException;
}
```

```java
public void exampleTest() throws BankingApiException{
    final String PIN = "1234";
    Account account = new Account();

    BankingApi bankingApi = mock(BankingApi.class);

    when(bankingApi.login(PIN)).thenReturn( account);
    when(bankingApi.getBalance(" NL98ING0000726635 ")).thenReturn(20000D);
    when(bankingApi.applyForLone(new Account())).thenReturn(true);
    when(bankingApi.transfer(3000D, "NL98ING0000726635", "NL96RAB0000347990")).thenReturn(true);
}
```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Mocking and Spring

* We use @ExtendsWith(MockitoExtension) to use mocking
* We need @ExtendsWith(SpringExtension) to use mocking and autowiring
* We use @Mock to specify the interfaces/classes that we want to mock
* @InjectMocks autowires the mock objects in the BankingClient class
* <ins>Note: We are testing the BankingClient class</ins>

```java
@ExtendWith(SpringExtension.class)
public class BankingClientTest {

    @Mock
    BankingApi bankingApi;

    @Mock
    LoanApi loanApi;

    @InjectMocks
    BankingClient bankingClient;
}


```

### Example test

```java
@Test
public void TransferSufficientFundsTest() throws BankingApiException {

    boolean succes = false;
    when(bankingApi.getBalance("12345")).thenReturn(100000D);

    succes = bankingClient.transfer(23000D, "12345", "23456");

    assertTrue(succes);
}

```

<br/><br/>
<br/><br/>
<div style="page-break-after: always;"></div>

## Lenient

When annotation ```@ExtendWith(MockitoExtension.class)``` is used, a test that contains ‘unused’ ‘when’ lines, will result in a UnnecessaryStubbingException being thrown

Use lenient() to avoid this

```java
@Test
public void givenLenientdStub_whenInvokingGetThenThrowUnnecessaryStubbingException() {
    List<String> mockList = Mockito.mock(ArrayList.class);
    mockList.add("two");
//  lenient().when(mockList.add("one")).thenReturn(true);
    when(mockList.add("one")).thenReturn(true);
    when(mockList.get(anyInt())).thenReturn("hello");
    assertEquals( "hello", mockList.get(1));
}

```

Use of ```@ExtendWith(SpringExtension.class)``` Does not throw this UnnecessaryStubbingException

<br/><br/>
<br/><br/>

## Exceptions

### We also need to test if exceptions are handled correctly


```java
// Not enough money in the account (balance)
when(bankingApi.getBalance("12345")).thenReturn(1000D);

Exception exception = Assertions.assertThrows(BankingApiException.class, () -> {
    // Amount to transfer > balance, so method transfer will throw a BankingApiException
    bankingClient.transfer(23000D, "12345", "23456");
});

// assert if correct message is in the BankinApiException
assertEquals("Amount exceeds balance", exception.getMessage());

```

## Case 1

Package: com.workshop.june8.cashregister

Class to test: CashRegister<br>

Create tests to:
* 'Checkout' several list of articles

<br/><br/>
<br/><br/>

## Case 2

Package: com.workshop.june8.calculation

Class to test: InterestCalculator<br>
Interface to mock: BankingService

Create tests to:
* calculate interest for different rates without date (today)
* calculate interest for different rates with date
* Inspect exception when service is not online

<br/><br/>
<br/><br/>

## Case 3

Package: com.workshop.june8.bankingapi

Class to test: BankingClient<br>
Interfaces to mock: BankingApi, LoanApi

Create tests to:
* Transfer money with sufficient funds
* Transfer money without sufficient funds
* Apply for a loan with sufficient funds
* Apply for a loan without sufficient funds
* Apply for a loan with while having debs
* Check the exceptions thrown



